package com.ecommerce.tests;

public class DynamicTests {

}
