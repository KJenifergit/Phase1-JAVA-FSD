package practiceproject1;
import java.util.*;

public class Mapprogram {
public static void main(String[] args) {
	

		
		//Hashmap
		HashMap<Integer,String>
		  hashmap=new HashMap<Integer,String>();      
		 hashmap.put(1,"cookies");    
		 hashmap.put(2,"chocolates");    
		 
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hashmap.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	     //HashTable
	       
	      Hashtable<Integer,String> hashtable=new Hashtable<Integer,String>();  
	      
	      hashtable.put(3,"cat");  
	      hashtable.put(4,"dog");  

	      System.out.println("\nThe elements of HashTable are ");  
	      for(Map.Entry n:hashtable.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	      //TreeMap
	      
	      TreeMap<Integer,String> treemap=new TreeMap<Integer,String>();    
	      treemap.put(5,"chennai");    
	      treemap.put(6,"bangalore");    
	         
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:treemap.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  
}



		
		