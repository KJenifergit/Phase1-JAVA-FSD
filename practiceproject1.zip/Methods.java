package practiceproject1;

public class Methods {
	
	//void method do not have any return type
			 public void methodDisplay() {
				System.out.println("Display method called");
			 }
			 
			 public int methodNumber() {
				 
				 int a=5,b=7;
				 return a+b;//return type
			 }
			
			 public static void main(String[] args) {
				 
				 Methods obj= new Methods();
				 obj.methodDisplay();
				 
				 int result=obj.methodNumber();
				 
				 System.out.println(result);
				
			}
		}





