package practiceproject1;

public class Array {
	public static void main(String[] args) {

		//single-dimensional array
		int a[]= {1,2,3,4,5,6,};
		for(int i=0;i<6;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimensional array
		int[][] b = {
		            {4, 4, 5}, 
		            {3, 8, 6,}};
		      
		      System.out.println("\nLength of row 1: " + b[1].length);
		      }
		}



