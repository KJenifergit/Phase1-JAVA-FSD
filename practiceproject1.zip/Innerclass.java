package practiceproject1;

public class Innerclass {
	private String msg="Welcome to Java programming"; 
	 
	 class Inner{  
	  void s1()
	  {
		  System.out.println(msg+", Let us we be a java full stack developer");}  
	 }  


	public static void main(String[] args) {

		Innerclass s=new Innerclass();
		Innerclass.Inner in=s.new Inner();  
		in.s1();  
	}
}

	 
     


