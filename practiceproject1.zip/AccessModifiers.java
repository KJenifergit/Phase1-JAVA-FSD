package practiceproject1;

public class AccessModifiers {
	void methodDefault() {
		System.out.println("This is default method");
	}
	public void methodPublic() {
		System.out.println("This is public method");
	}
	
	private void methodPrivate() {
		System.out.println("This is private method");
	}
	
	
	protected void methodProtected() {
		System.out.println("This is protected method");
	}
	
	
	public static void main(String [] args) {
		
		AccessModifiers method= new  AccessModifiers();
		
		method.methodDefault();
		method.methodPublic();
	    method.methodPrivate();
		method.methodProtected();
		
	
	}
}



