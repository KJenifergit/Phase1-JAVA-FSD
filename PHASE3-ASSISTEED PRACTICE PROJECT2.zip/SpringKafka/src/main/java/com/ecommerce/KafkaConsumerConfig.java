package com.ecommerce;

public class KafkaConsumerConfig {

}
