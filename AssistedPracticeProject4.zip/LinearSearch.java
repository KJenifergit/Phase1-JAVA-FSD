package AssistedPracticeProject4;
import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int arr[]={10,95,27,89,59,67,35};
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a value to be searched in the array");
		int key=scan.nextInt();
	
		boolean found=false;
		for(int val : arr){
			if(val==key){
				found=true;
				break;
			}
			
		}
		
		if(found==true)	
		System.out.println("Value is found in the array");
		
		else
			System.out.println("Value is not found in the array");

	}
		

}

