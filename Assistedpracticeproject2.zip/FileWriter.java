package Assistedpracticeproject2;
import java.io.File;
import java.io.PrintStream;

public class FileWriter {
	public FileWriter(String string) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String args[]) {
		String data = "We are from SSn";
		try {
			FileWriter output =new FileWriter("C:\\Users\\admin\\jeniferjava\\vfgyu.txt");
			
			 output.write(data);
			System.out.println("Data is written to the file");
			
			output.close();
		}
		catch (Exception e) {
			e.getStackTrace();
		}
	}

	private void write(String data) {
		// TODO Auto-generated method stub
		
	}

	private void close() {
		// TODO Auto-generated method stub
		
	}

}
