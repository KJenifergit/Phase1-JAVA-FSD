package com.demo;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

public class Capstone {

WebDriver driver;

@Test()
public void testOnChromeWithBrowserStackUrl()
{
System.setProperty("webdriver.chrome.driver", "H://selenium//chrome driver//chromedriver.exe");
driver=new ChromeDriver();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.get("file: \\\"c:\\Users\\admin\\BUDGET\\Drive Your Way\\index.html");
driver.manage().window().maximize();
System.out.println("this is the test related to chrome browserstack homepage"+ " " +Thread.currentThread().getId());

}

//@Test()
//public void testOnChromeWithBrowserStackSignUp()
//{
//System.setProperty("webdriver.gecko.driver", "H://selenium//geckodriver-v0.31.0-win64//geckodriver.exe");
//driver=new FirefoxDriver();
//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//driver.get("file: \\\"c:\\Users\\admin\\BUDGET\\Drive Your Way\\index.html");
//driver.manage().window().maximize();
//driver.findElement(By.id("user_full_name")).sendKeys("<name>");
//driver.findElement(By.id("user_email_login")).sendKeys("<6379272655>");
//driver.findElement(By.id("user_password")).sendKeys("<Jenifer>");
//System.out.println("this is the test related to FireFox browserstack login"+ " " +Thread.currentThread().getId());
//
//}

@AfterClass
public void close()
{
driver.quit();
}
}